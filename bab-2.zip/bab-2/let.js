//////////////////////////////////////////////////
// Nama file: let.js
//////////////////////////////////////////////////

for (let i=0; i<3; i++) {
   console.log('Nilai i: ' + i);
}

// salah, variabel i tidak dikenal
//console.log('\nDi luar blok pengulangan, nilai i: ' + i);
