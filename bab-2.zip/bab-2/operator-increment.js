//////////////////////////////////////////////////
// Nama file: operator-increment.js
//////////////////////////////////////////////////

var x;

// pre-increment
console.log('Pre-increment');
x = 9;
console.log(`x \t: ${x}`);
console.log(`++x \t: ${++x}`);
console.log(`x \t: ${x}`);
   
// post-increment
console.log('\nPost-increment');
x = 9;
console.log(`x \t: ${x}`);
console.log(`x++ \t: ${x++}`);
console.log(`x \t: ${x}`);
