//////////////////////////////////////////////////
// Nama file: interpolasi-variabel.js
//////////////////////////////////////////////////

var a = 8, b = 9, c = a + b;

console.log(`${a} + ${b} = ${c}`);
console.log(`${a} * ${b} = ${a * b}`);
console.log(`${a} / ${b} = ${a / b}`);
