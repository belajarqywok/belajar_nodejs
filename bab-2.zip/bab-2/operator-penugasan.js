//////////////////////////////////////////////////
// Nama file: operator-penugasan.js
//////////////////////////////////////////////////

var a = 1;
console.log('Nilai awal a: ' + a)

a += 1;		// a = a + 1
console.log('Setelah ditambah 1, nilai a: ' + a)

a *= 3;		// a = a * 3
console.log('Setelah dikali 3, nilai a: ' + a)

a /= 2;		// a = a / 2
console.log('Setelah dibagi 2, nilai a: ' + a)
