//////////////////////////////////////////////////
// Nama file: operator-bitwise.js
//////////////////////////////////////////////////

var a = 12, b = 10;

console.log(`a \t: ${a}`)
console.log(`b \t: ${b}`)
console.log(`a & b \t: ${a & b}`)
console.log(`a | b \t: ${a | b}`)
console.log(`a ^ b \t: ${a ^ b}`)
console.log(`~a \t: ${~a}`)
