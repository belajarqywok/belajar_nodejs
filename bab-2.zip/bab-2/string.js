//////////////////////////////////////////////////
// Nama file: string.js
//////////////////////////////////////////////////

var s1 = 'Pemrograman JavaScript';
var s2 = "Node.js";
var s3 = `Express (framework untuk Node.js)`;

console.log('s1: ' + s1);
console.log('s2: ' + s2);
console.log('s3: ' + s3);
