//////////////////////////////////////////////////
// Nama file: return.js
//////////////////////////////////////////////////

function kali(a, b) {	// BARIS A
   return a * b;		// BARIS B
}

var nilai1 = 10, nilai2 = 20, hasil;

// memanggil fungsi
hasil = kali(nilai1, nilai2);	// BARIS C
console.log(`${nilai1} x ${nilai2} = ${hasil}`);
