//////////////////////////////////////////////////
// Nama file: operator-decrement.js
//////////////////////////////////////////////////

var x;

// pre-decrement
console.log('Pre-decrement')
x = 9
console.log(`x \t: ${x}`)
console.log(`--x \t: ${--x}`)
console.log(`x \t: ${x}`)

// post-decrement
console.log('\nPost-decrement')
x = 9
console.log(`x \t: ${x}`)
console.log(`x-- \t: ${x--}`)
console.log(`x \t: ${x}`)
