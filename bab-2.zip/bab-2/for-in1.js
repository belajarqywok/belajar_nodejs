//////////////////////////////////////////////////
// Nama file: for-in1.js
//////////////////////////////////////////////////

var data = {'one':'satu', 'two':'dua', 'three':'tiga'};

for (let kunci in data) {
   console.log(`${kunci} \t: ${data[kunci]}`);
}
