//////////////////////////////////////////////////
// Nama file: multiline-string.js
//////////////////////////////////////////////////

var s1 = 'Dengan adanya Node.js,\n' +
         'JavaScript dapat digunakan untuk membuat\n' +
         'beragam tipe aplikasi';

var s2 = `Dengan adanya Node.js,
JavaScript dapat digunakan untuk membuat
beragam tipe aplikasi`;

console.log('s1: ' + s1);
console.log('\ns2: ' + s2);

