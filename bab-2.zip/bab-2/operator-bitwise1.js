//////////////////////////////////////////////////
// Nama file: operator-bitwise1.js
//////////////////////////////////////////////////

var a = 12;

console.log(`a \t: ${a}`)
console.log(`a >> 1 \t: ${a >> 1}`)
console.log(`a >> 2 \t: ${a >> 2}`)
console.log(`a << 1 \t: ${a << 1}`)
console.log(`a << 2 \t: ${a << 2}`)
