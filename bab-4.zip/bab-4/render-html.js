//////////////////////////////////////////////////
// Nama file: render-html.js
//////////////////////////////////////////////////

var http = require('http');
var fs = require('fs');

function renderHtml(path, response) {
   fs.readFile(path, null, function(error, data) {
      if (error) {
         response.writeHead(404);
         response.write('File tidak ditemukan');
      } else {
         response.write(data);
      }
      response.end();
   });
}

var server = http.createServer(function (request, response) {
   response.writeHead(200, {'Content-Type': 'text/html'});
   renderHtml('./index.html', response);   
});

server.listen(3000);
