//////////////////////////////////////////////////
// Nama file: rute.js
//////////////////////////////////////////////////

var http = require('http');

var server = http.createServer(function (request, response) {
   if (request.url == '/') {
      response.end('<h2>Halaman Utama</h2>');
   } else if (request.url == '/katalog') {
      response.end('<h2>Halaman Katalog</h2>');
   } else if (request.url == '/kontak') {
      response.end('<h2>Halaman Kontak</h2>');
   } else {
      response.status = 404;  // status HTTP untuk halaman tidak ditemukan
      response.end('<h2>404: Halaman Tidak Ditemukan</h2>');
   }
});

server.listen(3000);
