//////////////////////////////////////////////////
// Nama file: buat-tabel.js
//////////////////////////////////////////////////

var Client = require('mariasql');

var conn = new Client({
   host: 'localhost',
   user: 'budi',
   password: 'budi',
   db: 'nodedb'	// mengaktifkan database nodedb
});

// mendefinisikan perintah SQL yang akan dikirim
var sql = `
CREATE TABLE buku (
   buku_id CHAR(4) NOT NULL PRIMARY KEY,
   buku_judul VARCHAR(30),
   buku_penulis VARCHAR(25),
   buku_penerbit VARCHAR(20)
)`;

// mengirim perintah SQL
conn.query(sql, function (error, result) {
   if (error) {
      console.log('Tabel buku gagal dibuat');
      throw error;
   }
   console.log('Tabel buku berhasil dibuat');
});

conn.end();  // memutus koneksi
