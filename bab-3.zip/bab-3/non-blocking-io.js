//////////////////////////////////////////////////
// Nama file: non-blocking-io.js
//////////////////////////////////////////////////

console.log('Perintah pertama');
setTimeout(function() {
   console.log('Perintah kedua')
}, 2000);
console.log('Perintah ketiga');
