//////////////////////////////////////////////////
// Nama file: filename_dirname.js
//////////////////////////////////////////////////

console.log('__filename\t: ' + __filename);
console.log('__dirname\t: ' + __dirname);

console.log('\nprocess.argv[1]\t: ' + process.argv[1]);
console.log('process.cwd()\t: ' + process.cwd());
