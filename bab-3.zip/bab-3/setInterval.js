//////////////////////////////////////////////////
// Nama file: setInterval.js
//////////////////////////////////////////////////

function hello() {
   console.log('Hello Node.js!');
}

// mengeksekusi fungsi hello() setiap 1 detik
setInterval(hello, 1000);
