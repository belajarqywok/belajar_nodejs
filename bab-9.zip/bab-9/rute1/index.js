//////////////////////////////////////////////////
// Nama file: rute1/index.js
//////////////////////////////////////////////////

var express = require('express');
var app = express();

app.get('/', function (req, res) {
   var body = `
      <h2>Halaman Utama</h2>
      <a href="http://localhost:3000/katalog/123">Produk 123</a> | 
      <a href="http://localhost:3000/katalog/456">Produk 456</a> |
      <a href="http://localhost:3000/tidak-di-kenal">Rute lain</a>
   `;
   res.send(body);
});

app.get('/katalog/:idproduk', function (req, res) {
   var body = '<h2>Halaman Katalog</h2>' +
              '<p>Produk ' + req.params.idproduk + '</p>';
   res.send(body);
});

app.get('*', function (req, res) {
   res.send('<h2>404: Halaman tidak ditemukan</h2>');
});

app.listen(3000);
