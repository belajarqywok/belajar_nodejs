//////////////////////////////////////////////////
// Nama file: hello/index.js
//////////////////////////////////////////////////

var express = require('express');
var app = new express();

app.get('/', function (req, res) {
   res.send('<h2>Hello Express!</h2>');
});

app.listen(3000);
