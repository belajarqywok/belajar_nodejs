//////////////////////////////////////////////////
// Nama file: rute2/routes/index.js
//////////////////////////////////////////////////

var express = require('express');
var router = express.Router();

router.get('/', function (req, res) {
   var body = `
      <h2>Halaman Utama</h2>
      <a href="http://localhost:3000/katalog/123">Produk 123</a> | 
      <a href="http://localhost:3000/katalog/456">Produk 456</a> |
      <a href="http://localhost:3000/tidak-di-kenal">Rute lain</a>
   `;
   res.send(body);   
});

module.exports = router;
