//////////////////////////////////////////////////
// Nama file: rute2/routes/katalog.js
//////////////////////////////////////////////////

var express = require('express');
var router = express.Router();

router.get('/:idproduk', function (req, res) {
   var body = '<h2>Halaman Katalog</h2>' +
              '<p>Produk ' + req.params.idproduk + '</p>';
   res.send(body);
});

module.exports = router;
