//////////////////////////////////////////////////
// Nama file: rute2/routes/notfound.js
//////////////////////////////////////////////////

var express = require('express');
var router = express.Router();

router.get('*', function (req, res) {
   res.send('<h2>404: Halaman tidak ditemukan</h2>');
});

module.exports = router;
