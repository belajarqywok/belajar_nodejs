//////////////////////////////////////////////////
// Nama file: server.js
//////////////////////////////////////////////////

var http = require('http');
var MongoClient = require('mongodb').MongoClient;
var pug = require('pug');
var qs = require('querystring');
var url = require('url');

var listPug = './templates/list.pug';
var addFormPug = './templates/addform.pug';
var editFormPug = './templates/editform.pug';

var connectionString = 'mongodb://budi:1234@127.0.0.1:27017/nodedb';
var connectionOption = {useNewUrlParser: true};

MongoClient.connect(connectionString, connectionOption, 
function(dbConnectionError, client) {
	
   if (dbConnectionError) throw dbConnectionError;

   db = client.db(client.s.options.dbName);

   var server = http.createServer(function (req, res) {
      res.writeHead(200, {'Content-Type': 'text/html'});
      if (req.url === '/') {
	     db.collection('buku').find().toArray(
	     function (error, result) {
		    if (error) throw error;
		    var template = pug.renderFile(listPug, {books: result});
		    res.end(template);			 
	     });		  
      } else if (req.url === '/add') {
	     switch (req.method) {
		    case 'GET':
			   var template = pug.renderFile(addFormPug);
			   res.end(template);
			   break;		 
		    case 'POST':
			   var body = '';
			
			   req.on('data', function (data) { 
			      body += data;
			   });
			
			   req.on('end', function () { 
			      var form = qs.parse(body);
			      var newDocument = {
				     kode: form['buku_id'],
				     judul: form['buku_judul'],
				     penulis: form['buku_penulis'],
				     penerbit: form['buku_penerbit']
			      };				   
			      db.collection('buku').insertOne(newDocument, 
			      function (error, result) {
				     if (error) throw error;
				     // kode untuk redirect ke root document
				     res.writeHead(302,{'Location': '/'});
				     res.end();
			      });
			   });				
			   break;		 
	     }
      } else if (url.parse(req.url).pathname === '/edit') {		  
	     switch (req.method) {
		    case 'GET':
			   var id = qs.parse(url.parse(req.url).query).id;
			   var filter = { kode: id };
			   db.collection('buku').find(filter).toArray(
			   function (error, result) {
			      if (error) throw error;
			      var template = pug.renderFile(editFormPug, {book: result[0]});
			      res.end(template);
			   });				
			   break;		 
		    case 'POST':
			   var body = '';
			
			   req.on('data', function (data) { 
			      body += data;
			   });
			
			   req.on('end', function () { 
			      var form = qs.parse(body);
			      var filter = { kode: form['buku_id'] };
			      var newValue = {			      
				     $set: {
					    judul: form['buku_judul'],
					    penulis: form['buku_penulis'],
					    penerbit: form['buku_penerbit']
				     }
			      };
			      db.collection('buku').updateOne(filter, newValue, 
			      function (error, result) {
				     if (error) throw error;
				     // kode untuk redirect ke root document
				     res.writeHead(302,{'Location': '/'});
				     res.end();
			      });
			   });				
			   break;		 
	     }		  
      } else if (url.parse(req.url).pathname === '/delete') {		  
	     // mengambil nilai dari parameter id
	     var id = qs.parse(url.parse(req.url).query).id;
	     var filter = { kode: id };
	     db.collection('buku').deleteOne(filter, 
	     function (error, result) {
		    if (error) throw error;
		    // kode untuk redirect ke root document
		    res.writeHead(302,{'Location': '/'});
		    res.end();
	     });		  
      }
   });

   server.listen(3000);
   console.log('Server aktif di http://localhost:3000');

});
