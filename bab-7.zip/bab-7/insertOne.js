//////////////////////////////////////////////////
// Nama file: insertOne.js
//////////////////////////////////////////////////

var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://budi:1234@127.0.0.1:27017/nodedb'

MongoClient.connect(url, {useNewUrlParser: true}, function(error, client) {
   if (error) {
      console.log('Koneksi ke server MongoDB gagal');
      throw error;
   }
   
   // membuat objek dari kelas Db
   var db = client.db(client.s.options.dbName);
   
   var document = {
      kode:'B001', judul:'Practical Node.js', 
      penulis: 'Azat Mardan', penerbit: 'Apress'
   };
   
   // menambah dokumen
   db.collection('buku').insertOne(document, function (err, result) {
      if (err) throw err;      
      console.log('1 dokumen telah ditambahkan ke dalam koleksi');      
   });
   
   client.close();  // memutus koneksi
});
