//////////////////////////////////////////////////
// Nama file: buat-koleksi.js
//////////////////////////////////////////////////

var MongoClient = require('mongodb').MongoClient;
var url = 'mongodb://budi:1234@127.0.0.1:27017/nodedb'

MongoClient.connect(url, {useNewUrlParser: true}, function(error, client) {
   if (error) {
      console.log('Koneksi ke server MongoDB gagal');
      throw error;
   }
   
   // membuat objek dari kelas Db
   var db = client.db(client.s.options.dbName);
   
   // membuat koleksi
   db.createCollection('buku', function (err, result) {
      if (err) {
         console.log('Koleksi buku gagal dibuat');
         throw err;
      }
      console.log('Koleksi buku berhasil dibuat');      
   });
   
   client.close();  // memutus koneksi
});
