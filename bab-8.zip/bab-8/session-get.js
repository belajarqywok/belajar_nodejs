//////////////////////////////////////////////////
// Nama file: session-get.js
//////////////////////////////////////////////////

var http = require('http');
var pug = require('pug');
var NodeSession = require('node-session');

var mainPug = './templates/main.pug';
var page1Pug = './templates/page1.pug';
var page2Pug = './templates/page2.pug';

// membuat session
var session = new NodeSession({
   secret: 'Q3UBzdH9GEfiRCTKbi5MTPyChpzXLsTD'
});

var server = http.createServer(function (req, res) {
   
   // mengaktifkan session
   session.startSession(req, res, function () {
      res.writeHead(200, {'Content-Type': 'text/html'});

      if (req.url === '/') {
         // mendaftarkan variabel ke dalam session
         req.session.put('var1', 'Pemrograman Node.js');
         
         // menampilkan halaman utama
         var template = pug.renderFile(mainPug);
         res.end(template);
      } else if (req.url === '/page1') {	  
         // mengambil nilai variabel dari dalam session dari halaman 1
         var value = req.session.get('var1');
         
         // menampilkan halaman 1
         var template = pug.renderFile(page1Pug, {var1: value});
         res.end(template);
      } else if (req.url === '/page2') {
         // mengambil nilai variabel dari dalam session dari halaman 2
         var value = req.session.get('var1');
         
         // menampilkan halaman 2
         var template = pug.renderFile(page2Pug, {var1: value});
         res.end(template);
      } else {
         res.end('Halaman tidak ditemukan!');
      }   
   });
      
});

server.listen(3000);
